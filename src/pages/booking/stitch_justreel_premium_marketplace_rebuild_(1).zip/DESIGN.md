---
name: JustReel Design System
colors:
  surface: '#fff8f8'
  surface-dim: '#edd4d9'
  surface-bright: '#fff8f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff0f2'
  surface-container: '#ffe8ed'
  surface-container-high: '#fce2e8'
  surface-container-highest: '#f6dce2'
  on-surface: '#26181c'
  on-surface-variant: '#584047'
  inverse-surface: '#3c2c31'
  inverse-on-surface: '#ffecf0'
  outline: '#8c7077'
  outline-variant: '#e0bec6'
  surface-tint: '#b80964'
  primary: '#b80964'
  on-primary: '#ffffff'
  primary-container: '#ff4f9a'
  on-primary-container: '#5c002f'
  inverse-primary: '#ffb0c9'
  secondary: '#a73a05'
  on-secondary: '#ffffff'
  secondary-container: '#fe7944'
  on-secondary-container: '#661f00'
  tertiary: '#944369'
  on-tertiary: '#ffffff'
  tertiary-container: '#d2769e'
  on-tertiary-container: '#550e35'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffd9e2'
  primary-fixed-dim: '#ffb0c9'
  on-primary-fixed: '#3e001e'
  on-primary-fixed-variant: '#8e004b'
  secondary-fixed: '#ffdbcf'
  secondary-fixed-dim: '#ffb59a'
  on-secondary-fixed: '#380d00'
  on-secondary-fixed-variant: '#802900'
  tertiary-fixed: '#ffd8e5'
  tertiary-fixed-dim: '#ffb0cf'
  on-tertiary-fixed: '#3d0023'
  on-tertiary-fixed-variant: '#772b50'
  background: '#fff8f8'
  on-background: '#26181c'
  surface-variant: '#f6dce2'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 64px
    fontWeight: '700'
    lineHeight: 72px
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  caption:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  2xl: 48px
  3xl: 64px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
---

## Brand & Style

The design system is engineered for a high-end creator marketplace where visual storytelling meets enterprise reliability. The brand personality is premium, editorial, and effortless, aiming to evoke a sense of curated excellence and creative empowerment. 

The aesthetic follows a **Premium Minimalist** movement, blending the structural clarity of Apple’s interface with the lifestyle warmth of Airbnb. It prioritizes expansive whitespace, intentional "breathing room," and a sophisticated use of high-chroma warm accents. The UI is designed to disappear, acting as a gallery-grade frame for high-quality video content—drones, AI-generated reels, and cinematic wedding footage. 

Key visual drivers:
- **Refinement:** High-precision alignment and balanced proportions.
- **Warmth:** A palette that avoids cold neutrals in favor of subtle rose-tinted surfaces.
- **Fluidity:** Soft, generous corner radii and subtle transitions that mimic organic movement.

## Colors

The color strategy uses a **Warm Monochromatic-Analogous** approach. By anchoring the palette in rich pinks and sunset oranges, the system maintains a high-energy "creator" vibe without sacrificing professional integrity. 

- **Primary & Secondary:** These are reserved for high-intent actions and brand moments. The primary gradient should be used sparingly for "hero" actions (e.g., "Post a Project" or "Book Creator").
- **Neutrality with Intent:** Surfaces are not true greys; they are infused with a hint of the primary hue (`#FFF7FB`) to ensure the UI feels cohesive and premium rather than clinical.
- **Borders:** Used as subtle dividers that harmonize with the background rather than creating harsh visual breaks.

## Typography

This design system utilizes **Inter** for its systematic precision and neutral, high-legibility characteristics. The type hierarchy is intentionally "top-heavy," using large display sizes to create an editorial feel.

- **Scale:** Use `display-lg` exclusively for hero sections to make a bold, premium statement.
- **Weight:** Reserve 700 weight for headlines only. Body text should remain at 400 to maintain the "airy" feel of the interface.
- **Tracking:** Headlines use slightly tighter letter spacing (`-0.01em` to `-0.02em`) to provide a more "designed" and modern appearance, while labels use positive tracking for better readability at small scales.

## Layout & Spacing

The layout philosophy is a **Structured Fluid Grid**. It relies on generous internal padding to create a "gallery" effect, ensuring that video thumbnails and creator portfolios have enough space to shine without visual competition.

- **Grid:** Use a 12-column grid for desktop with 24px gutters. For mobile, shift to a 4-column grid with 16px margins.
- **Rhythm:** All spacing must be a multiple of 4px. Use `xl` (32px) and `2xl` (48px) for vertical section spacing to maintain the premium, high-whitespace aesthetic.
- **Container:** Maximum content width is capped at 1280px to ensure line lengths remain readable on ultra-wide monitors.

## Elevation & Depth

Hierarchy is established through **Ambient Shadows** and **Tonal Layering** rather than heavy borders.

- **The "Lift" Effect:** Interactive elements (cards, primary buttons) use an extra-diffused shadow with a subtle primary-hue tint. 
- **Levels:**
  - **Level 0 (Base):** `#FFFFFF` - The main canvas.
  - **Level 1 (Surface):** `#FFF7FB` - Used for secondary content areas or sidebar backgrounds.
  - **Level 2 (Cards):** White background with a `0 4px 20px rgba(243, 214, 228, 0.4)` shadow.
  - **Level 3 (Overlays):** Modals and dropdowns use a deeper shadow: `0 12px 40px rgba(26, 26, 26, 0.08)`.
- **Glassmorphism:** Use background blurs (20px) on the Navbar and floating action buttons to maintain context and depth as the user scrolls through vibrant video content.

## Shapes

The shape language is defined by **Soft Geometric** forms. This design system moves away from "standard" web rounding toward more exaggerated, "squircle"-like corners that feel friendly yet modern.

- **Standard Elements (Inputs/Buttons):** Use `0.5rem` (rounded-md).
- **Cards & Containers:** Use `1.5rem` (rounded-xl) to `2rem` (rounded-2xl) to emphasize the soft, high-end feel.
- **Avatars:** Always 100% circular to contrast against the geometric grid.

## Components

### Buttons
- **Primary:** Gradient background (`linear-gradient(135deg, #FF4F9A, #FF7A45)`), white text. On hover: a subtle 2px lift via shadow. On click: a light ripple effect.
- **Secondary:** White background, `#FF4F9A` border (1px) and text. On hover: `#FFF7FB` background.
- **Ghost:** No background or border. `#666666` text. On hover: `#FF4F9A` text with a subtle `0.05` opacity background.

### Cards
- **Reel Cards:** Aspect ratio 9:16. `2rem` rounded corners. Title and creator name overlay at the bottom with a subtle dark-to-transparent gradient for legibility.
- **Creator Cards:** White background, `1.5rem` rounded corners, subtle `F3D6E4` border. Showcases a circular avatar and a "Featured Work" horizontal scroll.

### Inputs
- **Text Inputs:** `#FFF7FB` background, `0.5rem` roundedness, no border initially. On focus: `#FFFFFF` background with a 1px `#FF4F9A` border and a soft glow shadow.
- **Labels:** Always use `label-sm` in `#1A1A1A` positioned above the input field.

### Navigation
- **Navbar:** Height 80px. Background: `#FFFFFF` with 0.8 opacity and `backdrop-filter: blur(20px)`. Subtle bottom border of `#F3D6E4`.
- **Footer:** Minimalist design using `surface` background (`#FFF7FB`). Four columns max, emphasizing social links and legal links in `caption` size.